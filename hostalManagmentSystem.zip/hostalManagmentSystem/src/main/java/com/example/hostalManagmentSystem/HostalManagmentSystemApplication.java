package com.example.hostalManagmentSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HostalManagmentSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(HostalManagmentSystemApplication.class, args);
	}

}
